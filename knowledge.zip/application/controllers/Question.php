<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Question extends CI_Controller {

	public function index()
	{
		if(($this->session->userdata('userid'))){
		}else{ redirect('Login'); }

		$this->load->view('template/header');
		$this->load->view('question');
		$this->load->view('template/footer');
	}

	public function add_question()
	{
		if(($this->session->userdata('userid'))){
		}else{ redirect('Login'); }


		$this->form_validation->set_rules('title', 'Question title', 'required|english_check');

		$this->form_validation->set_rules('category_id', 'Category', 'required');
		
		$this->form_validation->set_rules('description', 'Description', 'required|min_length[10]');

		if ($this->form_validation->run() == FALSE)
		{

			$this->load->view('template/header');
			$this->load->view('add_question');
			$this->load->view('template/footer');

		}else{

	
				$data['title']=$this->input->post('title');
				$data['description']=nl2br($this->input->post('description'));
				$data['code']=$this->input->post('code');
				$data['tag']=$this->input->post('tag');
				$data['user_id']=$this->session->userdata('user_id');
					
				$this->db->insert('questions',$data);
				
				
				$last_id=$this->db->insert_id();
					
				$msg='<div class="alert alert-success"> Your Question Created </div>';
					
				$this->session->set_flashdata('message',$msg);
					
				redirect('Showquestion/view/'.$last_id.'');
	
		$this->session->set_flashdata('message',$msg);
			redirect($_SERVER['HTTP_REFERER']);

		
	}

}
}
 