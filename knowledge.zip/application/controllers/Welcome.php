<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{

		/*$query=  $this->db->select('*')->from('products')->order_by('review','desc')->limit(9)->get();
		$data['popular_products'] = $query->result_array();
*/
		$this->load->view('template/header');
		$this->load->view('home');
		$this->load->view('template/footer');
	}
}
 