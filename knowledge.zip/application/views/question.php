    <!-- events -->
    <section class="blog_w3ls py-5" id="events">
        <div class="container py-xl-5 py-lg-3">
            <h3 class="title-w3 mb-5 text-center font-weight-bold">Recent Questions</h3>
             <div class="col-md-4 offset-5">
                            <a class="service-btn" href="#">Do you have any question?</a>
                        </div>
            <div class="row mt-lg-2">
                <!-- blog grid -->
              <a href="ss" style="margin-bottom: 10px;">
                    <div class="col-lg-12 col-md-12 mt-lg-0 mt-5">
                    <div class="card">
                        <div class="card-header m-0">
                           
                        </div>
                        <div class="card-body" style="padding: .7rem;">
                            <p class="text-left">Proin eget tortor risus. Curabitur aliquet quam id dui posuere
                                blandit. Vivamus
                                magna justo,
                                lacinia eget consectetur sed, convallis at tellus. Vestibulum ac diam sit.</p>
                        </div>
                        <div class="card-footer blog_w3icon border-top pt-2 mt-3 d-flex justify-content-between" style="margin-top: 0px;padding: 0.1rem 1.25rem">
                            <small class="text-bl">
                                <b>By: Loremipsum</b>

                          
                            </small>
                            <p>  <i class="fa fa-eye"> 4 </i>
                            <i class="fa fa-reply-all"> 11</i></p>
                            <span>
                                March 24,2019
                            </span>

                        </div>
                    </div>
                </div>
              </a>
                <!-- //blog grid -->

                <!-- blog grid -->
              <a href="ss" style="margin-bottom: 10px;">
                    <div class="col-lg-12 col-md-12 mt-lg-0 mt-5">
                    <div class="card">
                        <div class="card-header m-0">
                           
                        </div>
                        <div class="card-body" style="padding: .7rem;">
                            <p class="text-left">Proin eget tortor risus. Curabitur aliquet quam id dui posuere
                                blandit. Vivamus
                                magna justo,
                                lacinia eget consectetur sed, convallis at tellus. Vestibulum ac diam sit.</p>
                        </div>
                        <div class="card-footer blog_w3icon border-top pt-2 mt-3 d-flex justify-content-between" style="margin-top: 0px;padding: 0.1rem 1.25rem">
                            <small class="text-bl">
                                <b>By: Loremipsum</b>

                          
                            </small>
                            <p>  <i class="fa fa-eye"> 4 </i>
                            <i class="fa fa-reply-all"> 11</i></p>
                            <span>
                                March 24,2019
                            </span>

                        </div>
                    </div>
                </div>
              </a>
                <!-- //blog grid -->
                <!-- blog grid -->
              <a href="ss" style="margin-bottom: 10px;">
                    <div class="col-lg-12 col-md-12 mt-lg-0 mt-5">
                    <div class="card">
                        <div class="card-header m-0">
                           
                        </div>
                        <div class="card-body" style="padding: .7rem;">
                            <p class="text-left">Proin eget tortor risus. Curabitur aliquet quam id dui posuere
                                blandit. Vivamus
                                magna justo,
                                lacinia eget consectetur sed, convallis at tellus. Vestibulum ac diam sit.</p>
                        </div>
                        <div class="card-footer blog_w3icon border-top pt-2 mt-3 d-flex justify-content-between" style="margin-top: 0px;padding: 0.1rem 1.25rem">
                            <small class="text-bl">
                                <b>By: Loremipsum</b>

                          
                            </small>
                            <p>  <i class="fa fa-eye"> 4 </i>
                            <i class="fa fa-reply-all"> 11</i></p>
                            <span>
                                March 24,2019
                            </span>

                        </div>
                    </div>
                </div>
              </a>
                <!-- //blog grid -->
                <!-- blog grid -->
              <a href="ss" style="margin-bottom: 10px;">
                    <div class="col-lg-12 col-md-12 mt-lg-0 mt-5">
                    <div class="card">
                        <div class="card-header m-0">
                           
                        </div>
                        <div class="card-body" style="padding: .7rem;">
                            <p class="text-left">Proin eget tortor risus. Curabitur aliquet quam id dui posuere
                                blandit. Vivamus
                                magna justo,
                                lacinia eget consectetur sed, convallis at tellus. Vestibulum ac diam sit.</p>
                        </div>
                        <div class="card-footer blog_w3icon border-top pt-2 mt-3 d-flex justify-content-between" style="margin-top: 0px;padding: 0.1rem 1.25rem">
                            <small class="text-bl">
                                <b>By: Loremipsum</b>

                          
                            </small>
                            <p>  <i class="fa fa-eye"> 4 </i>
                            <i class="fa fa-reply-all"> 11</i></p>
                            <span>
                                March 24,2019
                            </span>

                        </div>
                    </div>
                </div>
              </a>
                <!-- //blog grid -->
                <!-- blog grid -->
              <a href="ss" style="margin-bottom: 10px;">
                    <div class="col-lg-12 col-md-12 mt-lg-0 mt-5">
                    <div class="card">
                        <div class="card-header m-0">
                           
                        </div>
                        <div class="card-body" style="padding: .7rem;">
                            <p class="text-left">Proin eget tortor risus. Curabitur aliquet quam id dui posuere
                                blandit. Vivamus
                                magna justo,
                                lacinia eget consectetur sed, convallis at tellus. Vestibulum ac diam sit.</p>
                        </div>
                        <div class="card-footer blog_w3icon border-top pt-2 mt-3 d-flex justify-content-between" style="margin-top: 0px;padding: 0.1rem 1.25rem">
                            <small class="text-bl">
                                <b>By: Loremipsum</b>

                          
                            </small>
                            <p>  <i class="fa fa-eye"> 4 </i>
                            <i class="fa fa-reply-all"> 11</i></p>
                            <span>
                                March 24,2019
                            </span>

                        </div>
                    </div>
                </div>
              </a>
                <!-- //blog grid -->
                       
            </div>
        </div>

    </section>
    <!-- //events -->
